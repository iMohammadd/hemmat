<?php

class Insurance extends \Eloquent {
	protected $fillable = [];
}