<?php

class Income extends \Eloquent {
	protected $fillable = [];
}