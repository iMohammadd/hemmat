<ul>
    <li>{{link_to_route('main', 'جستجو')}}</li>
    <li>{{link_to_route('add_person', 'افزودن مددجو')}}</li>
    <li>{{link_to_route('states', 'استانها')}}</li>
    <li>{{link_to_route('aids', 'کمکها')}}</li>
    <li>{{link_to_route('incomes', 'درآمدها')}}</li>
    <li>{{link_to_route('insurances', 'بیمه ها')}}</li>
    <li>{{link_to_route('change_password', 'تغییر کلمه عبور')}}</li>
    <li>{{link_to_route('logout', 'خروج')}}</li>
</ul>