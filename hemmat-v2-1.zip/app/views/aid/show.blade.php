@extends('master')
@section('title')
    جستجو بر اساس درآمد
@endsection
@section('right')
    @include('tags')
@endsection
@section('left')
    @include('persons')
@endsection