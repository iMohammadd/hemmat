@extends('master')
@section('title')
    جستجو بر اساس بیمه
@endsection
@section('right')
    @include('tags')
@endsection
@section('left')
    @include('persons')
@endsection