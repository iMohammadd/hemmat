<?php

class Aid extends \Eloquent {
	protected $fillable = [];
}