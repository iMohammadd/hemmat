-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2015 at 01:49 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hemmatv2`
--

-- --------------------------------------------------------

--
-- Table structure for table `aids`
--

CREATE TABLE IF NOT EXISTS `aids` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `aids`
--

INSERT INTO `aids` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'جهیزیه', '2015-02-18 17:11:13', '2015-02-18 17:11:13'),
(2, 'درمان', '2015-02-26 16:57:35', '2015-02-26 16:57:35');

-- --------------------------------------------------------

--
-- Table structure for table `incomes`
--

CREATE TABLE IF NOT EXISTS `incomes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `incomes`
--

INSERT INTO `incomes` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'بهزیستی', '2015-02-18 17:27:26', '2015-02-18 17:27:26'),
(2, 'نیروهای مسلح', '2015-02-26 16:57:51', '2015-02-26 16:57:51');

-- --------------------------------------------------------

--
-- Table structure for table `insurances`
--

CREATE TABLE IF NOT EXISTS `insurances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `insurances`
--

INSERT INTO `insurances` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'تامین اجتماعی', '2015-02-18 17:31:48', '2015-02-18 17:31:48'),
(2, 'خدمات درمانی', '2015-02-26 16:58:11', '2015-02-26 16:58:11');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2015_02_16_093656_create_persons_table', 1),
('2015_02_16_094027_create_users_table', 1),
('2015_02_16_094243_create_aids_table', 1),
('2015_02_16_094322_create_incomes_table', 1),
('2015_02_16_094400_create_insurances_table', 1),
('2015_02_16_094428_create_states_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `persons`
--

CREATE TABLE IF NOT EXISTS `persons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `person_code` int(10) unsigned NOT NULL,
  `tel` int(11) DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(10) unsigned NOT NULL,
  `aid_id` int(10) unsigned NOT NULL,
  `income_id` int(10) unsigned NOT NULL,
  `insurance_id` int(10) unsigned NOT NULL,
  `document` text COLLATE utf8_unicode_ci NOT NULL,
  `aid_amount` int(10) unsigned NOT NULL,
  `cheq_amount` int(10) unsigned NOT NULL,
  `cheq_number` int(10) unsigned NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `persons`
--

INSERT INTO `persons` (`id`, `report_id`, `name`, `person_code`, `tel`, `address`, `state_id`, `aid_id`, `income_id`, `insurance_id`, `document`, `aid_amount`, `cheq_amount`, `cheq_number`, `date`, `created_at`, `updated_at`) VALUES
(1, 1234567890, 'مملی محمدی', 1234567890, 0, 'پاستور', 1, 1, 1, 1, 'document/1234567890.jpeg', 2000000, 7000000, 141981, '1424649600', '2015-02-20 16:01:19', '2015-02-27 03:33:31'),
(2, 13820, 'مهدی یاحقی', 4294967295, 0, 'صادقیه، نبش کسرایی و اسدی', 2, 2, 1, 1, 'document/9876543210.jpeg', 400000, 0, 0, '1425859200', '2015-02-26 17:00:32', '2015-02-26 17:00:32'),
(3, 1218, 'مهدی یاحقی', 1239874560, 2122233668, 'اندیمشک - کوی لور', 1, 1, 1, 1, 'document/1239874560.jpeg', 100000, 0, 0, '1425168000', '2015-02-27 02:53:40', '2015-02-27 02:53:40');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'تهران', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'قم', '2015-02-18 16:35:13', '2015-02-18 16:35:13'),
(3, 'مشهد', '2015-02-26 16:57:18', '2015-02-26 16:57:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$0mQZjtn4KcEHEejls45YW.9mOa6M0lr1VxFAUZ6ZNyx2eLxoo28oy', 'admin@hemmat110.com', 'R0Bd0LUG121N0BgmV6gdWltxFC3rzUTeqoQG44zscWwyfgRUr3goijQXPuC8', '2015-02-16 17:11:21', '2015-02-27 16:16:55');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
